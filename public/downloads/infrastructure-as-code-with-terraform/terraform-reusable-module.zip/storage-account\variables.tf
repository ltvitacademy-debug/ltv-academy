# ---------------------------------------------------------------------------
# modules/storage-account/variables.tf
#
# Every input this module accepts (Chapter 4, Lesson 18). `environment` and
# `resource_group_name` have no default, so Terraform refuses to plan until
# every caller supplies them; `location` and `replication_type` do, so a
# caller can omit them entirely.
# ---------------------------------------------------------------------------

variable "environment" {
  type        = string
  description = "Short environment name, e.g. dev, staging, prod. Used to build the storage account name."
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group this storage account is created in."
}

variable "location" {
  type        = string
  default     = "eastus2"
  description = "Azure region for the storage account."
}

variable "replication_type" {
  type        = string
  default     = "LRS"
  description = "Storage replication type, e.g. LRS, GRS, ZRS. Production environments should pass a tougher tier than the default."

  validation {
    condition     = contains(["LRS", "GRS", "RAGRS", "ZRS", "GZRS", "RAGZRS"], var.replication_type)
    error_message = "replication_type must be one of LRS, GRS, RAGRS, ZRS, GZRS, RAGZRS."
  }
}
