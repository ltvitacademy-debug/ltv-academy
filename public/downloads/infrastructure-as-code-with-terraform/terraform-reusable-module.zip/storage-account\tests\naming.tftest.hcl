# ---------------------------------------------------------------------------
# modules/storage-account/tests/naming.tftest.hcl
#
# Chapter 4, Lesson 20: run with `terraform test` from inside
# modules/storage-account/. Both runs use `command = plan`, so no real
# Azure resources are created -- these are fast, free, structural checks.
# ---------------------------------------------------------------------------

variables {
  environment          = "test"
  resource_group_name  = "rg-northbridge-test"
}

run "name_follows_convention" {
  command = plan

  assert {
    condition     = azurerm_storage_account.this.name == "stnbretailtest"
    error_message = "Storage account name didn't follow the expected stnbretail<environment> convention."
  }
}

run "private_by_default" {
  command = plan

  assert {
    condition     = azurerm_storage_account.this.public_network_access_enabled == false
    error_message = "Storage account must not be publicly accessible by default."
  }
}

run "replication_defaults_to_lrs" {
  command = plan

  assert {
    condition     = azurerm_storage_account.this.account_replication_type == "LRS"
    error_message = "Default replication type should be LRS when replication_type is not overridden."
  }
}
