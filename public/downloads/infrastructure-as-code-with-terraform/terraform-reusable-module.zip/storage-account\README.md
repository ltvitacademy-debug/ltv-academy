# storage-account

Northbridge Retail's reusable Azure storage account module -- the pattern built across Chapter 4 (Writing Modules, Module Inputs & Outputs, Module Versioning & Structure).

## Usage

```hcl
module "storage_dev" {
  source              = "./modules/storage-account"
  environment         = "dev"
  resource_group_name = azurerm_resource_group.dev.name
  location            = "eastus2"
  replication_type    = "LRS"
}

module "storage_prod" {
  source              = "./modules/storage-account"
  environment         = "prod"
  resource_group_name = azurerm_resource_group.prod.name
  location            = "eastus2"
  replication_type    = "GRS"
}
```

Reading a module output elsewhere in your configuration:

```hcl
resource "azurerm_linux_function_app" "pipeline" {
  name                       = "func-nbretail-pipeline-dev"
  resource_group_name        = azurerm_resource_group.dev.name
  location                   = azurerm_resource_group.dev.location
  storage_account_name       = module.storage_dev.storage_account_name
  storage_account_access_key = module.storage_dev.primary_access_key
  service_plan_id            = azurerm_service_plan.dev.id
}
```

## Inputs

| Name | Type | Default | Description |
|---|---|---|---|
| `environment` | string | (required) | Short environment name, e.g. dev, staging, prod. Used to build the storage account name. |
| `resource_group_name` | string | (required) | Name of the resource group this storage account is created in. |
| `location` | string | `"eastus2"` | Azure region for the storage account. |
| `replication_type` | string | `"LRS"` | Storage replication type -- LRS, GRS, RAGRS, ZRS, GZRS, or RAGZRS. |

## Outputs

| Name | Description |
|---|---|
| `storage_account_id` | Resource ID of the storage account. |
| `storage_account_name` | Name of the storage account. |
| `primary_blob_endpoint` | Primary blob storage endpoint URL. |
| `primary_access_key` | Primary access key (sensitive). |

## Notes

- `public_network_access_enabled = false` is hardcoded, not a variable -- this module is deliberately private-by-default, and `tests/naming.tftest.hcl` asserts on exactly that so a future edit can't silently flip it.
- No `version` argument is needed when calling this module with a local `source` path -- version pinning only applies to registry or other remote module sources (Lesson 20).
- Run `terraform test` from this directory before trusting a change to `main.tf`.
