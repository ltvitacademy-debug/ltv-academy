# ---------------------------------------------------------------------------
# modules/storage-account/outputs.tf
#
# A module's entire public surface beyond its variables (Chapter 4,
# Lesson 18). Nothing else inside this module -- not the resource itself,
# not any local value -- is reachable from whatever calls it.
# ---------------------------------------------------------------------------

output "storage_account_id" {
  description = "Resource ID of the storage account."
  value       = azurerm_storage_account.this.id
}

output "storage_account_name" {
  description = "Name of the storage account -- commonly fed into a dependent resource such as a Function App."
  value       = azurerm_storage_account.this.name
}

output "primary_blob_endpoint" {
  description = "Primary blob storage endpoint URL."
  value       = azurerm_storage_account.this.primary_blob_endpoint
}

output "primary_access_key" {
  description = "Primary access key for the storage account. Sensitive -- never printed by terraform plan/apply output."
  value       = azurerm_storage_account.this.primary_access_key
  sensitive   = true
}
