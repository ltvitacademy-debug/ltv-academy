# ---------------------------------------------------------------------------
# modules/storage-account/main.tf
#
# Northbridge Retail's reusable storage-account module -- the exact pattern
# Chapter 4 (Writing Modules, Lesson 17) builds: a resource that used to be
# copy-pasted once per environment, now parameterized so dev, staging, and
# prod call the same module with different inputs.
# ---------------------------------------------------------------------------

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
}

resource "azurerm_storage_account" "this" {
  name                     = "stnbretail${var.environment}"
  resource_group_name     = var.resource_group_name
  location                = var.location
  account_tier             = "Standard"
  account_replication_type = var.replication_type

  # Lesson 20's "safe-by-default" test (tests/naming.tftest.hcl) asserts on
  # exactly this value -- a module that defaults to public access would pass
  # a casual "did it apply" check while shipping an insecure default to
  # every environment that calls it.
  public_network_access_enabled = false

  tags = {
    environment = var.environment
    managed_by  = "terraform"
    module      = "storage-account"
  }
}
