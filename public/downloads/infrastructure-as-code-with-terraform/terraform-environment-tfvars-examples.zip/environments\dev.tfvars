# environments/dev.tfvars
# Chapter 7, Lesson 29: directory-per-environment pattern -- this file lives
# in environments/dev/ alongside its own backend config, and is applied
# with: terraform apply -var-file=dev.tfvars
#
# NOTE: this file holds only non-sensitive defaults. Real secrets (DB
# passwords, API keys) are never put in a .tfvars file -- see Lesson 33
# and secrets-handling-checklist.md in this same resource set. This file
# itself is also listed in .gitignore's *.tfvars rule.

environment          = "dev"
resource_group_name  = "rg-northbridge-dev"
location             = "eastus2"
replication_type     = "LRS"

instance_count       = 1
vm_size              = "Standard_B1s"
enable_autoscaling   = false
log_retention_days   = 7
