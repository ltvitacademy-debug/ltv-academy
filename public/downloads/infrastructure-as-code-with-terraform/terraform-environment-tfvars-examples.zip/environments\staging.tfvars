# environments/staging.tfvars
# Mirrors dev.tfvars but closer to prod's shape -- staging exists to catch
# problems a single-instance dev environment never would.

environment          = "staging"
resource_group_name  = "rg-northbridge-staging"
location             = "eastus2"
replication_type     = "LRS"

instance_count       = 2
vm_size              = "Standard_B2s"
enable_autoscaling   = true
log_retention_days   = 30
