# environments/prod.tfvars
# Production gets the tougher replication tier (Lesson 17/18's module
# example), more instances, and a much longer log retention window for
# compliance. Applying this file against the wrong workspace/directory is
# exactly the mistake Lesson 29 explains directory-per-environment exists
# to prevent -- there is no single flag here that can silently target prod.

environment          = "prod"
resource_group_name  = "rg-northbridge-prod"
location             = "eastus2"
replication_type     = "GRS"

instance_count       = 6
vm_size              = "Standard_D2s_v5"
enable_autoscaling   = true
log_retention_days   = 365
