// Lesson 38, Step 3: the main() entry point.
// Build this yourself following Lesson 38 -- process.argv, exit
// codes, and reading the Result<T> from chain.ts.
