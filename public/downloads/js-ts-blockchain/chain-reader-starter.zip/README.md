# chain-reader

Starter scaffold for the JS/TS for Blockchain Development capstone
(Lessons 37-39). See Lesson 37 for the full project spec and
definition of done.

## Setup

```
npm install
cp .env.example .env   # then fill in RPC_URL
```

## Build it

Fill in `src/config.ts`, `src/chain.ts`, and `src/index.ts` following
Lesson 38. Run with:

```
npx tsx src/index.ts <address>
```

## Write your own README

Lesson 39 has you replace this file with your own, documenting what
you built -- that's the actual capstone deliverable, not this stub.
