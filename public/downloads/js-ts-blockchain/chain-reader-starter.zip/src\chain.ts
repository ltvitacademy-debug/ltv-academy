// Lesson 38, Step 2: the typed provider wrapper returning Result<T>.
// Build this yourself following Lesson 38 -- the Result<T> + address
// type patterns are also available pre-built in this course's other
// resource-vault download, typed-web3-snippets.ts, if you want a
// reference while you write your own version here.
