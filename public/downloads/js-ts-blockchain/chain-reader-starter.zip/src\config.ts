// Lesson 38, Step 1: validated environment config.
// Fill this in exactly as Lesson 38 shows -- write it yourself rather
// than copying it, since typing it out once is what makes the zod
// pattern stick.
//
// import "dotenv/config";
// import { z } from "zod";
//
// const envSchema = z.object({
//   RPC_URL: z.string().url(),
// });
//
// export const env = envSchema.parse(process.env);
